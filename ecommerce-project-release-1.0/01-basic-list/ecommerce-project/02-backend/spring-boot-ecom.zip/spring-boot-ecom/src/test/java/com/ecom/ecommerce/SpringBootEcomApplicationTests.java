package com.ecom.ecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEcomApplicationTests {

	@Test
	void contextLoads() {
	}

}
